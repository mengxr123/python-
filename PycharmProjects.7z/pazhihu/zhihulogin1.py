from pytesseract import image_to_string
from PIL import Image
import sys
import sys


im = Image.open('e:\\captcha.jpg')

if (im is not None):
    print(image_to_string(im))