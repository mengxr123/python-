from zhihulogin import *
from bs4 import BeautifulSoup
import gevent
from gevent.queue import Queue

from gevent import sleep
from gevent.pool import Pool
from gevent.coros import BoundedSemaphore
import datetime


queue = Queue()

def worun(myse,s):
    yy = 100
    while yy!=0:
        r = myse.get(queue.get()+'/followers', headers=headers)

        soup = BeautifulSoup(r.text, "html.parser")
        for i in soup.find_all(class_='author-link-line'):
            queue.put(i.a["href"])
            print (i.a["href"])
        yy=yy-1

if __name__=='__main__':
    logininfo = zhihulogin('13032921196','198443')
    logininfo.login()
    myse=logininfo.get_session()

    url = 'https://www.zhihu.com/people/oliver-43'

    queue.put(url)
    now = datetime.datetime.now()
    otherStyleTime = now.strftime("%Y-%m-%d %H:%M:%S")
    print('star time' + otherStyleTime)
    list = [gevent.spawn(worun,myse,i) for i in range(100)]
    gevent.joinall(list)
    now1 = datetime.datetime.now()
    StyleTime = now1.strftime("%Y-%m-%d %H:%M:%S")
    print('end time' + StyleTime)

