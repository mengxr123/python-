import requests
try:
    import cookielib
except:
    import http.cookiejar as cookielib
import re
import time
import os.path

# 构造 Request headers
agent = 'Mozilla/5.0 (Windows NT 5.1; rv:33.0) Gecko/20100101 Firefox/33.0'
headers = {
    'User-Agent': agent
}

class zhihulogin:

    def __init__(self,account,secret):
        print("ログイン初期化 ユーザ名:%s  パスワード:%s"%(secret,account))
        self.account=account
        self.secret=secret
        self.post_url = 'http://www.zhihu.com/login/phone_num'

        self._session = requests.session()
        self._session.cookies = cookielib.LWPCookieJar(filename='cookies')
        try:
            self._session.cookies.load(ignore_discard=True)
        except:
            print("Cookie 未能加载")

        self.postdata = {
            'password': secret,
            'remember_me': 'true',
            'phone_num': account,
        }

    def __getxsrf(self):
        index_page = self._session.get('http://www.zhihu.com', headers=headers)
        html = index_page.text
        pattern = r'name="_xsrf" value="(.*?)"'
        _xsrf = re.findall(pattern, html)
        return _xsrf[0]

    # 获取验证码
    def __getcaptcha(self):
        t = str(int(time.time() * 1000))
        captcha_url = 'http://www.zhihu.com/captcha.gif?r' + t + "&type=login"
        r = self._session.get(captcha_url, headers=headers)
        with open('captcha.jpg', 'wb') as f:
            f.write(r.content)
            f.close()
        print(u'请到 %s 目录找到captcha.jpg 手动输入' % os.path.abspath('captcha.jpg'))
        captcha = input("please input the captcha\n>")
        return captcha

    def login(self):

        self.postdata["_xsrf"] = self.__getxsrf()
        self.postdata["captcha"] = self.__getcaptcha()

        login_page =  self._session.post(self.post_url, data=self.postdata, headers=headers)
        login_code = eval(login_page.text)
        print(login_code['msg'])
        self._session.cookies.save()

    def get_session(self):
        return self._session

if __name__=='__main__':
    pass











