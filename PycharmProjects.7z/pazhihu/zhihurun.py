from zhihulogin import *
from bs4 import BeautifulSoup
import multiprocessing
import time
from multiprocessing import Process,Queue,Pool
from multiprocessing.pool import ThreadPool

import datetime

def worun(queue,myse,lock,s):
    yy=100
    while yy!=0:
        r = myse.get(queue.get()+'/followers', headers=headers)
        #print(s)
        soup = BeautifulSoup(r.text, "html.parser")
        lock.acquire()
        for i in soup.find_all(class_='author-link-line'):
            queue.put(i.a["href"])
            print (i.a["href"])
        lock.release()
        yy=yy-1


if __name__=='__main__':
    logininfo = zhihulogin('13032921196','198443')
    logininfo.login()
    myse=logininfo.get_session()

    url = 'https://www.zhihu.com/people/oliver-43'

    manager = multiprocessing.Manager()
    queue = manager.Queue()
    lock = manager.Lock()

    pool=ThreadPool(100)
    queue.put(url)

    now = datetime.datetime.now()
    otherStyleTime = now.strftime("%Y-%m-%d %H:%M:%S")
    print('star time' + otherStyleTime)
    for i in range(100):
        pool.apply_async(worun,args=(queue,myse,lock,i))

    pool.close()
    pool.join()
    now1 = datetime.datetime.now()
    StyleTime = now1.strftime("%Y-%m-%d %H:%M:%S")
    print('end time' + StyleTime)





