from multiprocessing import Pool
from bs4 import BeautifulSoup
from zhihulogin import *
from gevent import monkey
monkey.patch_all()


import queue


q = queue.Queue(0)

logininfo = zhihulogin('13032921196','198443')
logininfo.login()


q.put('https://www.zhihu.com/people/oliver-43')

def runrun(session):

    url = q.get()+'/followers'
    print(url)
    r = session.get(url, headers=headers)
    soup = BeautifulSoup(r.text, "html.parser")

    for i in soup.find_all(class_='author-link-line'):
        print(i.a['href'])
        q.put(i.a['href'])



sessionss=session
pool = Pool(processes=4)  # set the processes max number 3
result = pool.apply_async(runrun,(sessionss,))
pool.close()
pool.join()